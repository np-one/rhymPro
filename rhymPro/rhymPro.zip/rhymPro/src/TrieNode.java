public class TrieNode {
    TrieNode[] arr;
    boolean isEnd;

    //constructor
    public TrieNode() {
        this.arr = new TrieNode[26];
    }
}

